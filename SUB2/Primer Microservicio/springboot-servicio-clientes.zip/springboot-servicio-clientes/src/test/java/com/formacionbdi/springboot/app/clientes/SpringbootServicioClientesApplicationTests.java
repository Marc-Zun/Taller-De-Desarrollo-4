package com.formacionbdi.springboot.app.clientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}

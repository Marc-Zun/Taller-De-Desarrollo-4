package com.formacionbdi.springboot.app.clientes.models.service;

import java.util.List;
import com.formacionbdi.springboot.app.clientes.models.entity.Cliente;

public interface IClienteService {
	
	public List<Cliente> findAll();
	public Cliente findBy(Long id);

}

package com.formacionbdi.springboot.app.clientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootServicioClientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootServicioClientesApplication.class, args);
	}

}

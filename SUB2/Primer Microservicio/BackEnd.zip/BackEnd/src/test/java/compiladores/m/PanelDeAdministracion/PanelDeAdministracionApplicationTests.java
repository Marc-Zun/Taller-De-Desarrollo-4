package compiladores.m.PanelDeAdministracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PanelDeAdministracionApplicationTests {

	@Test
	void contextLoads() {
	}

}

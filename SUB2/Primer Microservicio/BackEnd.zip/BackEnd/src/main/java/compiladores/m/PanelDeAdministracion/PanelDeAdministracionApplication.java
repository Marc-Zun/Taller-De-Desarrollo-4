package compiladores.m.PanelDeAdministracion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanelDeAdministracionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanelDeAdministracionApplication.class, args);
	}

}

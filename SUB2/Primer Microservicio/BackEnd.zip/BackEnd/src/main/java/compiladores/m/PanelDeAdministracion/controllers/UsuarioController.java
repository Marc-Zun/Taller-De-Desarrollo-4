package compiladores.m.PanelDeAdministracion.controllers;

import compiladores.m.PanelDeAdministracion.models.Usuario;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class UsuarioController {
   List<Usuario> usuarios = new ArrayList<>();

    @GetMapping("/api/usuarios")
    public List<Usuario> listarUsuarios(){


    return usuarios;

    }

    @DeleteMapping("/api/usuarios/{id}")
    public void eliminarUsuario(@PathVariable String id){

        Usuario usuarioEncontrado = usuarios.stream().filter(user -> user.getId().toString().equals(id)).findFirst().get();

        usuarios.remove(usuarioEncontrado);


    }
    @PostMapping("/api/usuarios")
    public void agregarUsuario(@RequestBody Usuario user){

        usuarios.add(user);


    }


}

package compiladores.m.PanelDeAdministracion.models;

import lombok.*;
import org.springframework.web.bind.annotation.RestController;

@Data @AllArgsConstructor
public class Usuario {


    private Integer id;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;



}
